mensaje = "Hola mundo"
print(type(mensaje))

# Clase: es el plano de construccion
# Objeto: una instancia de una clase


# Clase : Humano
# Objeto: Nicoles , Felipe, Maria, Juan ...
