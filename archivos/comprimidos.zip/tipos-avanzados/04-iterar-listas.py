mascotas = ["Wolfgang", "Pelusa", "Perseo", "Pulga", "Copito"]


for indice, mascota in enumerate(mascotas):
    print(indice, mascota)
