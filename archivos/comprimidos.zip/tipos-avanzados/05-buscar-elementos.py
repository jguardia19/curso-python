mascotas = ["Wolfgang", "Pulga", "Pelusa", "Perseo", "Pulga", "Copito"]

print(mascotas.count("Pulga"))
if "Pulgas" in mascotas:
    print(mascotas.index("Pulgas"))
