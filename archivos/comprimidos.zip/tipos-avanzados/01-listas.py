numeros = [1, 2, 3]
letras = ["a", "b", "c"]
palabras = ["chanchito", "Feliz"]
booleans = [True, False, True, True]
matriz = [[0, 1], [1, 0]]
ceros = [0, 1] * 10
alfanumericos = numeros + letras
rango = list(range(1, 11))
chars = list("Hola Mundo")
print(chars)
