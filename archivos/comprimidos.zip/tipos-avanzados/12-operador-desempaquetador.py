lista = [1, 2, 3, 4]
# tupla = (1, 2, 3, 4)
# print(*lista)
# print(*tupla)

# lista2 = [5, 6]

# combinada = [0, *lista, 4.5, *lista2, 7]
# print(combinada)


punto1 = {"x": 19}
punto2 = {"y": 15}

nuevoPunto = {**punto1, **punto2}
print(nuevoPunto)
