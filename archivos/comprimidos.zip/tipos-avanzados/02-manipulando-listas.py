mascotas = ["Wolfgang", "Pelusa", "Perseo", "Pulga", "Copito"]
print(mascotas[0])
mascotas[0] = "Bicho"
# print(mascotas)
# print(mascotas[0:3])
# print(mascotas[-1])  # ultimo elemento
# print(mascotas[::2])  # elementos pares
# print(mascotas[1::2])  # saltando elementos

numeros = list(range(21))
print(numeros[::2])
print(numeros[1::2])
