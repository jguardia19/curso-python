edad = 19

# if edad > 17:
#     mensaje = "Es mayor"
# else:
#     mensaje = "es menor"

mensaje = "Es mayor" if edad > 17 else "es menor"

print(mensaje)
