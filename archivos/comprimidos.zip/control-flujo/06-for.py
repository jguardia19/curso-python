buscar = 10
for numero in range(5):
    print(numero)
    if numero == buscar:
        print("encontrado", buscar)
        break
else:
    print("No encontre el numero")


for char in "Jose Guardia":
    print(char)
