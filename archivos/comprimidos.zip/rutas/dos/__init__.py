def init(graphql, **_):
    print(f"Soy modulo 2 {graphql}")
