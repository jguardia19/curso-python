def init(db, api, **_):
    print(f"Soy modulo uno {db} {api}")
