nombre_curso = "Ultimate Python"
descripcion_curso = """
Ultimate Python,
este curso contiene todo lo que 
necesitas para aprender.
"""

# print(nombre_curso, descripcion_curso)
print(len(nombre_curso))
print(nombre_curso[0])
print(nombre_curso[0:8])
print(nombre_curso[9:])
print(nombre_curso[:8])
print(nombre_curso[:])
