numero = 2  # entero  -> integer
decimal = 1.2  # float
imaginario = 2 + 2j  # 2 + 2i

# numero = numero + 2
numero += 2
numero -= 5
numero *= 4
numero /= 7


print(1 + 3)
print(1 - 3)
print(1 * 3)
print(1 / 3)
print(1 // 3)  # solo muestra parte entera
print(1 % 3)
print(2 ** 3)
