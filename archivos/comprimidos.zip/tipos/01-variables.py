nombre_curso = "Ultimate Python"
print(nombre_curso)
alumnos = 5000
puntaje = 9.9
publicado = True
