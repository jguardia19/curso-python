nombre = "Nicolas"
apellido = "Shurmann"
# nombre_completo = nombre + " " + apellido
nombre_completo = f"{nombre} {apellido}"
print(nombre_completo)
