"""Introduccion a Python"""

print("hola Mundo!")
print("el weta " * 4)
