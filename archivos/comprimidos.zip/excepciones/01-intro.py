try:
    n1 = int(input("Ingresa primer numero: "))
except:
    print("ocurrio un error :(")
