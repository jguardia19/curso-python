def largo(texto):
    resultado = 0
    for _ in texto:
        resultado += 1
    return resultado


print("Chanchito")
l = largo("Hola Mundo")
print(l)
