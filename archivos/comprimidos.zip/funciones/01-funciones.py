def hola(nombre, apellido="Feliz"):  # parametros
    print("Hola Mundo")
    print(f"Bienvenido {nombre} {apellido}")


hola("Jose", "Guardia")  # argumentos
hola("Chanchito")  # argumentos


hola(apellido="aular", nombre="gregorio")
