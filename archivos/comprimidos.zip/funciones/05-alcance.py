saludo = "Hola Global"


def saludar():
    saludo = "Hola Mundo"


def saludarChanchito():
    saludo = "Hola Chanchito"
